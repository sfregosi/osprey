function tol = defaultTolerance(delays)
%defaultTolerance	User didn't provide a tolerance; make one up.
%
% tol = defaultTolerance(delays)

tol = max(abs(delays)) * 0.05;
