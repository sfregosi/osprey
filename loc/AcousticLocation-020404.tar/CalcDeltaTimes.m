function delta = CalcDeltaTimes (x,array,h1,h2,measuredDelay)
% function delta = CalcDeltaTimes (x,array,h1,h2,measuredDelay)
% 
% 	Computes theoretical time delays from given 2-d coordinates (x),
%	assuming given hydrophone locations, and subtracts these
%	from the given measured time delays, producing a vector of
%	time delay errors.
%
%	x		2 x 1		Location to compute time delays for
%	array		2 x n		Positions of hydrophones
%	h1		1 x m		First hydrophone indices
%	h2		1 x m		Second hydrophone indices
%	measuredDelay	1 x m		Measured time delays between
%					first and second hydrophones
%	delta		m x 1		Time delay differences

m = length(measuredDelay);

delta = zeros(m,1);

for i=1:m,
	delta(i) = dist(x,array(:,h1(i))) - ...
	           dist(x,array(:,h2(i))) - ...
	           measuredDelay(i);
end

