function jac = CalcDeltaJacobian (x,array,h1,h2,measuredDelay)
% function jac = CalcDeltaJacobian (x,array,h1,h2,measuredDelay)
%
%	Computes gradient of the time delay difference function
%	(see CalcDeltaTimes.m).
%
%	x		2 x 1	    Location to compute Jacobian for
%	array		2 x n	    Positions of hydrophones
%	h1		1 x m	    First hydrophone indices
%	h2		1 x m	    Second hydrophone indices
%	measuredDelay	1 x m	    Measured time delays between first and
%				    second hydrophones (only length matters)
%	jac		2 x m	    Time delay differences function Jacobian
%				    transpose

dxy1 = [x(1)-array(1,h1); x(2)-array(2,h1)];
dxy2 = [x(1)-array(1,h2); x(2)-array(2,h2)];

d1 = sqrt(sum(dxy1 .^ 2));
d2 = sqrt(sum(dxy2 .^ 2));

if (any([d1;d2] == 0))
  disp('zero in CalcDeltaJ')
  keyboard
end
jac = dxy1./[d1;d1] - dxy2./[d2;d2];
