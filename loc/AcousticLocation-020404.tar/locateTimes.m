
% This script runs Steve Mitchell's locator, using a given array
% and the arrival times of sounds at the phones in this array.
% Upon entry, you need these variables defined:
%
%    arr        phone positions (2xN array; meters)
%    arrivals   arrival times of the sound at each phone (seconds)
%    p          (optional) which phones (from arr and arrivals) to use
%    c          speed of sound (m/s)
%    limits     (optional) display limits of plot [minX maxX minY maxY]
%    resolution (optional) grid size for finding best-fit loc (m)
%    tolerance  (optional) time-of-arrival error allowed (s) (used in plotting)
%
% This routine displays the phones, plots the hyperbolas, calculates the
% best location, and prints and plots it.  It also sets these variables:
%
%    xopt       optimal X-Y position (m)
%    actual     actual arrival-time differences
%    calc       arrival-time differences for optimal position
%    err        difference between actual and calc
%    m          squared error
%    sigma      mean error


if (~exist('limits')), limits = []; end
if (~exist('tolerance')), tolerance = []; end
if (~exist('resolution')), resolution = []; end
if (~exist('p')), p = []; end

if (~isempty(p)), p1 = p;
else p1 = 1 : size(arr,2); 
end
plotPhones(arr(:,p1), limits);                   % turns hold on

[m1,m2,d] = timesToDelays(p1, arrivals);
useful = PlotHyperbolas(d, tolerance, arr, m1, m2, c, limits);

disp('Finding loc...');
[xopt,actual,calc,err,m] = bestFit(m1(useful), m2(useful), d(useful), ...
    arr, limits, resolution, c);
sigma = showResults(xopt, m1(useful), m2(useful), actual, calc, err, m, c);
