function [m1,m2,d,useful] = enterTimes(arr, c, tolerance, limits)
%enterTimes	Enter a set of sound arrival times to use in localization.
%
% [m1,m2,d,useful] = enterTimes(arr, c, tolerance, limits)
%    Have the user enter a set of arrival times at each phone.  
%
%
% Required input arguments:
%    arr	[2xN]     x- and y-positions, m
%    c		[scalar]  speed of sound, m/s (~343 in air, ~1500 in seawater)
% Optional input arguments:
%    tolerance	[scalar]  error in time delays, s (used only in plotting)
%    limits	[1x4]     axes limits of plot, m [xMin xMax yMin yMax]
%
% Values entered when this function executes:
%    - number of phones
%    - for each phone, the time that the sound signal arrived at that phone
%
% Outputs:
%    m1		[1xM]  first phone number of each pair
%    m2		[1xM]  second phone number of each pair
%    d		[1xM]  arrival-time delay between phone 1 and phone 2, seconds;
%		       d > 0 if the sound reached phone 1 first, < 0 if phone 2
%                      first (this is the negative of Canary's correlation 
%                      offset value)
%    useful	[1xM]  whether each phone-pair value is less than the maximum
%                      possible delay

global previousM1 previousM2 previousD scale scaleText

if (~exist('previousM1')), previousM1 = []; end

if (nargin < 3), tolerance = []; end
if (nargin < 4), limits    = []; end

checkScale('init')
plotPhones(arr, limits);	% turns hold on

if (length(previousM1))
  nn = input('Number of phones? [enter NaN to use previous set] ');
else
  nn = input('Number of phones? ');
end

if (isnan(nn))

  % Use previous values.
  m1 = previousM1;
  m2 = previousM2;
  d  = previousD;

else
  
  for i = 1 : nn
    h(i) = input('Enter phone number: ');
    t(i) = input(sprintf('Enter arrival time%s: ', scaleText));
    if (i > 1)
      checkScale(t(i) - t(i-1));
    end
    disp(' ')
  end
  
  t = t / scale;
  [m1,m2,d] = timesToDelays(h, t);

  previousM1 = m1;
  previousM2 = m2;
  previousD = d;
end
hold off

useful = PlotHyperbolas(d, tolerance, arr, m1, m2, c, limits);
