function limits = defaultLimits(arr)
% defaultLimits		calculate plotting limits since user didn't supply them
% 
% limits = defaultLimits(arr)
%    Given arr, a 2xN array of phone positions, calculate plotting limits
%    that leave as much space around the array in x and y as the extent of
%    the array itself.  The extent is the maximum of the extent in x and y.

A = [min(arr'); max(arr')];
extent = max(diff(A));
limits = [1;1] * mean(A) + extent * [-1.5 -1.5; 1.5 1.5];
limits = limits(:)';
