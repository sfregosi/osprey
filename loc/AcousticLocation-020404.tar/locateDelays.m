
% This script runs Steve Mitchell's locator, using a given array
% and the arrival times of sounds at the phones in this array.
% Upon entry, you need these variables defined:
%
%    arr        [2xN] phone positions (m)
%    delays     [1xM] delay times of the sound between pairs of phones (s)
%    m1, m2	[1xM] between which phones was the delay measured?
%    c          speed of sound (m/s)
%    limits     (optional) display limits of plot [minX maxX minY maxY]
%    resolution (optional) grid size for finding best-fit loc (m)
%    tolerance  (optional) time-of-arrival error allowed (s) (used in plotting)
%
% This routine displays the phones, plots the hyperbolas, calculates the
% best location, and prints and plots it.  It also sets these variables:
%
%    xopt       optimal X-Y position (m)
%    actual     actual arrival-time differences
%    calc       arrival-time differences for optimal position
%    err        difference between actual and calc
%    m          squared error
%    sigma      mean error


if (~exist('limits')), limits = []; end
if (~exist('tolerance')), tolerance = []; end
if (~exist('resolution')), resolution = []; end

plotPhones(arr, limits);                   % turns hold on
useful = PlotHyperbolas(delays, tolerance, arr, m1, m2, c, limits);

disp('Finding loc...');
[xopt,actual,calc,err,m] = bestFit(m1(useful), m2(useful), delays(useful), ...
    arr, limits, resolution, c);
sigma = showResults(xopt, m1(useful), m2(useful), actual, calc, err, m, c);
